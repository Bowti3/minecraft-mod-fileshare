//////////////////////////////////////////
// Complementary Shaders by EminGT      //
// With Euphoria Patches by SpacEagle17 //
//////////////////////////////////////////

//Common//
#include "/lib/common.glsl"
#include "/lib/shaderSettings/wavingBlocks.glsl"
#define SHADOW_SATURATION 1.0 //[0.5 0.6 0.7 0.8 0.9 1.0 1.1 1.2 1.3 1.4 1.5 1.6 1.7 1.8 1.9 2.0]
//#define DISCARD_FOLIAGE_SHADOW

#if defined MIRROR_DIMENSION || defined WORLD_CURVATURE
    #include "/lib/misc/distortWorld.glsl"
#endif

//////////Fragment Shader//////////Fragment Shader//////////Fragment Shader//////////
#ifdef FRAGMENT_SHADER

flat in int mat;

in vec2 texCoord;

in vec4 position;
flat in vec4 glColor;

#ifdef CONNECTED_GLASS_EFFECT
    in vec2 signMidCoordPos;
    flat in vec2 absMidCoordPos;
#endif

//Pipeline Constants//
#include "/lib/pipelineSettings.glsl"

//Common Variables//
vec3 upVec = normalize(gbufferModelView[1].xyz);

vec3 sunVec = GetSunVector();

float SdotU = dot(sunVec, upVec);
float sunVisibility = clamp(SdotU + 0.0625, 0.0, 0.125) / 0.125;

//Common Functions//
void DoNaturalShadowCalculation(inout vec4 color1, inout vec4 color2) {
    color1.rgb *= glColor.rgb;
    color1.rgb = mix(vec3(1.0), color1.rgb, pow(color1.a, (1.0 - color1.a) * 0.5) * 1.05);
    color1.rgb *= 1.0 - pow(color1.a, 64.0);
    color1.rgb *= 0.1; // 423HDSS: Shadow color strength is stored 10 times lower to allow for water shadows going above 1.0

    color2.rgb = normalize(color1.rgb) * 0.5;
}

//Includes//
#include "/lib/util/dither.glsl"

#ifdef CONNECTED_GLASS_EFFECT
    #include "/lib/materials/materialMethods/connectedGlass.glsl"
#endif

//Program//
void main() {
    #ifdef DISCARD_FOLIAGE_SHADOW
        if (mat == 10003 || mat == 10005 || mat == 10015 || mat == 10017 || mat == 10019 || mat == 10021 || mat == 10023 || mat == 10029 || mat == 10031 || mat == 10039) discard; // Foliage
    #endif

    vec4 color1 = texture2DLod(tex, texCoord, 0); // Shadow Color
    #ifdef SHADOW_COLORWHEEL
        vec2 lmCoord; // needed as otherwise undeclared in the function below
        float ao;
        vec4 overlayColor;

        clrwl_computeFragment(color1, color1, lmCoord, ao, overlayColor);
    #endif

    #if HIDE_ARMOR > 0
        if (currentRenderedItemId == 45124 && !isElytraFlying) discard;
    #endif

    if (entityId > 0) {
        #if PLAYER_SHADOW == -1
            if (entityId == 50016 || entityId == 50017) { // Player
                discard;
            }
        #endif

        // Entity Shadow Fade Out
        float fadeEnd = shadowDistance * entityShadowDistanceMul + 2.0;
        float fadeStart = fadeEnd * 0.8;
        float opacity = 1.0 - smoothstep(fadeStart, fadeEnd, max(length(position.xz), abs(position.y)));

        float dither = Bayer64(gl_FragCoord.xy);
        if (opacity < dither) discard;
    }

    #if SHADOW_QUALITY >= 1
        vec4 color2 = color1; // Light Shaft Color

        color2.rgb *= 0.25; // Natural Strength

        #if defined LIGHTSHAFTS_ACTIVE && LIGHTSHAFT_BEHAVIOUR == 1 && defined OVERWORLD
            float positionYM = position.y;
        #endif

        if (mat < 32008) {
            if (mat < 32000) {
                #if defined CONNECTED_GLASS_EFFECT || defined LIGHTSHAFTS_ACTIVE && LIGHTSHAFT_BEHAVIOUR == 1 && defined OVERWORLD
                    if (mat == 30008 || mat >= 31000) { // Tinted Glass || Stained Glass, Stained Glass Pane
                        #ifdef CONNECTED_GLASS_EFFECT
                            DoSimpleConnectedGlass(color1);
                        #endif

                        #if defined LIGHTSHAFTS_ACTIVE && LIGHTSHAFT_BEHAVIOUR == 1 && defined OVERWORLD
                            positionYM = 0.0; // 86AHGA: For scene-aware light shafts to be less prone to get extreme under large glass planes
                        #endif
                    }
                #endif
                DoNaturalShadowCalculation(color1, color2);
            } else {
                if (mat == 32000) { // Water
                    vec3 worldPos = position.xyz + cameraPosition;

                    #if defined LIGHTSHAFTS_ACTIVE && LIGHTSHAFT_BEHAVIOUR == 1 && defined OVERWORLD
                        // For scene-aware light shafts to be more prone to get extreme near water
                        positionYM += 3.5;
                    #endif

                    // Water Caustics
                    #if WATER_CAUSTIC_STYLE < 3
                        #if MC_VERSION >= 11300
                            float wcl = pow2(GetLuminance(color1.rgb));
                            color1.rgb = color1.rgb * wcl * 1.2;
                            color1.rgb *= mix(1.0, WATER_CAUSTIC_STRENGTH, wcl);
                        #else
                            color1.rgb = mix(color1.rgb, vec3(GetLuminance(color1.rgb)), 0.88);
                            color1.rgb = pow2(color1.rgb) * vec3(2.5, 3.0, 3.0) * 0.96;
                        #endif
                    #else
                        #define WATER_SPEED_MULT_M WATER_SPEED_MULT * 0.035
                        vec2 causticWind = vec2(0.0, frameTimeCounter * WATER_SPEED_MULT_M);
                        vec2 cPos1 = worldPos.xz * 0.08 + causticWind;
                        vec2 cPos2 = worldPos.xz * 0.06 - causticWind;

                        float cMult = 14.0;
                        float offset = 0.001;

                        float caustic = 0.0;
                        caustic += dot(texture2D(gaux4, cPos1 + vec2(offset, 0.0)).rg, vec2(cMult))
                                 - dot(texture2D(gaux4, cPos1 - vec2(offset, 0.0)).rg, vec2(cMult));
                        caustic += dot(texture2D(gaux4, cPos2 + vec2(0.0, offset)).rg, vec2(cMult))
                                 - dot(texture2D(gaux4, cPos2 - vec2(0.0, offset)).rg, vec2(cMult));
                        color1.rgb = vec3(max0(min1(caustic * 0.8 + 0.35)) * 0.65 + 0.35);

                        #if MC_VERSION < 11300
                            color1.rgb *= vec3(0.3, 0.45, 0.9);
                        #endif

                        color1.rgb *= mix(1.0, WATER_CAUSTIC_STRENGTH, caustic);
                    #endif

                    #if MC_VERSION >= 11300
                        #if WATERCOLOR_MODE >= 2
                            color1.rgb *= glColor.rgb;
                        #else
                            color1.rgb *= vec3(0.3, 0.45, 0.9);
                        #endif
                    #endif
                    color1.rgb *= vec3(0.6, 0.8, 1.1);
                    color1.rgb = pow(color1.rgb, vec3(0.75)) * 0.5;
                    ////

                    // Underwater Light Shafts
                    vec3 worldPosM = worldPos;

                    #if WATER_FOG_MULT > 100
                        #define WATER_FOG_MULT_M WATER_FOG_MULT * 0.01;
                        worldPosM *= WATER_FOG_MULT_M;
                    #endif

                    vec2 waterWind = vec2(syncedTimeDynamic * 0.01, 0.0);
                    float waterNoise = texture2DLod(noisetex, worldPosM.xz * 0.012 - waterWind, 0.0).g;
                          waterNoise += texture2DLod(noisetex, worldPosM.xz * 0.05 + waterWind, 0.0).g;

                    float factor = max(2.5 - 0.025 * length(position.xz), 0.8333) * 1.3;
                    waterNoise = pow(waterNoise * 0.5, factor) * factor * 1.3;

                    #if MC_VERSION >= 11300 && WATERCOLOR_MODE >= 2
                        color2.rgb = normalize(sqrt1(glColor.rgb)) * vec3(0.24, 0.22, 0.26);
                    #else
                        color2.rgb = vec3(0.08, 0.12, 0.195);
                    #endif
                    color2.rgb *= waterNoise * (1.0 + sunVisibility - rainFactor);
                    ////

                    #ifdef UNDERWATERCOLOR_CHANGED
                        color1.rgb *= vec3(UNDERWATERCOLOR_RM, UNDERWATERCOLOR_GM, UNDERWATERCOLOR_BM);
                        color2.rgb *= vec3(UNDERWATERCOLOR_RM, UNDERWATERCOLOR_GM, UNDERWATERCOLOR_BM);
                    #endif
                } else /*if (mat == 32004)*/ { // Ice
                    color1.rgb *= color1.rgb;
                    color1.rgb *= color1.rgb;
                    color1.rgb = mix(vec3(1.0), color1.rgb, pow(color1.a, (1.0 - color1.a) * 0.5) * 1.05);
                    color1.rgb *= 1.0 - pow(color1.a, 64.0);
                    color1.rgb *= 0.14; // 423HDSS

                    color2.rgb = normalize(pow(color1.rgb, vec3(0.25))) * 0.5;
                }
            }
        } else {
            if (mat < 32020) { // Glass, Glass Pane, Beacon (32008, 32012, 32016)
                #ifdef CONNECTED_GLASS_EFFECT
                    if (mat == 32008) { // Glass
                        DoSimpleConnectedGlass(color1);
                    }
                    if (mat == 32012) { // Glass Pane
                        DoSimpleConnectedGlass(color1);
                    }
                #endif
                if (color1.a > 0.5) color1 = vec4(0.0, 0.0, 0.0, 1.0);
                else color1 = vec4(vec3(0.1 * (1.0 - GLASS_OPACITY)), color1.a); // 423HDSS
                color2.rgb = vec3(0.3);

                #if defined LIGHTSHAFTS_ACTIVE && LIGHTSHAFT_BEHAVIOUR == 1 && defined OVERWORLD
                    positionYM = 0.0; // 86AHGA
                #endif
            } else {
                DoNaturalShadowCalculation(color1, color2);
            }
        }
    #endif
    #ifdef RAIN_ATMOSPHERE
        if (entityId == 50004) discard; // remove lightning shadows
    #endif
    #if END_CRYSTAL_VORTEX_INTERNAL / 2 == 1
        if (entityId == 50200) discard; // remove end crystal healing beam
    #endif

    /* DRAWBUFFERS:0 */
    gl_FragData[0] = vec4(saturateColors(color1.rgb, SHADOW_SATURATION), color1.a); // Shadow Color

    #if SHADOW_QUALITY >= 1
        #if defined LIGHTSHAFTS_ACTIVE && LIGHTSHAFT_BEHAVIOUR == 1 && defined OVERWORLD
            color2.a = 0.25 + max0(positionYM * 0.05); // consistencyMEJHRI7DG
        #endif
        /* DRAWBUFFERS:01 */
        gl_FragData[1] = vec4(saturateColors(color2.rgb, pow(SHADOW_SATURATION, 0.8)), color2.a); // Light Shaft Color
    #endif
}

#endif

//////////Vertex Shader//////////Vertex Shader//////////Vertex Shader//////////
#ifdef VERTEX_SHADER

flat out int mat;

out vec2 texCoord;

out vec4 position;
flat out vec4 glColor;

#ifdef CONNECTED_GLASS_EFFECT
    out vec2 signMidCoordPos;
    flat out vec2 absMidCoordPos;
#endif

//Pipeline Constants//
#if COLORED_LIGHTING_INTERNAL > 0 || END_CRYSTAL_VORTEX_INTERNAL > 0 || DRAGON_DEATH_EFFECT_INTERNAL > 0 || defined END_PORTAL_BEAM_INTERNAL
    #extension GL_ARB_shader_image_load_store : enable
#endif

//Attributes//
attribute vec4 mc_Entity;
attribute vec4 mc_midTexCoord;
attribute vec4 at_midBlock;

//Common Variables//
vec2 lmCoord;

#if COLORED_LIGHTING_INTERNAL > 0
    writeonly uniform uimage3D voxel_img;

    #ifdef PUDDLE_VOXELIZATION
        writeonly uniform uimage2D puddle_img;
    #endif

    #if WORLD_SPACE_REFLECTIONS_INTERNAL > 0
        writeonly uniform uimage3D wsr_img;
        writeonly uniform uimage3D wsr_lod_img;
    #endif

    #ifdef ACT_GROUND_LEAVES_FIX
        writeonly uniform uimage3D leaves_img;
    #endif
#endif

//Common Functions//

//Includes//
#include "/lib/util/spaceConversion.glsl"

#if defined WAVING_ANYTHING_TERRAIN || defined WAVE_EVERYTHING || defined WAVING_WATER_VERTEX
    #include "/lib/materials/materialMethods/wavingBlocks.glsl"
#endif

#if COLORED_LIGHTING_INTERNAL > 0
    #include "/lib/voxelization/lightVoxelization.glsl"

    #ifdef PUDDLE_VOXELIZATION
        #include "/lib/voxelization/puddleVoxelization.glsl"
    #endif

    #if WORLD_SPACE_REFLECTIONS_INTERNAL > 0
        #include "/lib/voxelization/reflectionVoxelization.glsl"
    #endif
    #ifdef ACT_GROUND_LEAVES_FIX
        #include "/lib/voxelization/leavesVoxelization.glsl"
    #endif
#endif

#if END_CRYSTAL_VORTEX_INTERNAL > 0 || DRAGON_DEATH_EFFECT_INTERNAL > 0 || defined END_PORTAL_BEAM_INTERNAL
    #include "/lib/voxelization/endCrystalVoxelization.glsl"
#endif

#if DRAGON_DEATH_EFFECT_INTERNAL > 0
    uniform isampler2D endcrystal_sampler;
#endif

//Program//
void main() {
    texCoord = gl_MultiTexCoord0.xy;
    lmCoord = GetLightMapCoordinates();
    glColor = gl_Color;
    mat = int(mc_Entity.x + 0.5);

    #if defined WORLD_CURVATURE || defined MIRROR_DIMENSION
        position = shadowModelViewInverse * gl_ModelViewMatrix * gl_Vertex;
    #else
        position = shadowModelViewInverse * shadowProjectionInverse * ftransform();
    #endif

    #ifdef WORLD_CURVATURE
        position.y += doWorldCurvature(position.xz);
    #endif

    #ifdef MIRROR_DIMENSION
        doMirrorDimension(position);
    #endif

    #if defined WAVING_ANYTHING_TERRAIN || defined WAVING_WATER_VERTEX || defined WAVE_EVERYTHING
        DoWave(position.xyz, mat);
        #ifdef WAVE_EVERYTHING
            DoWaveEverything(position.xyz);
        #endif
    #endif

    #ifdef CONNECTED_GLASS_EFFECT
        vec2 midCoord = (gl_TextureMatrix[0] * mc_midTexCoord).st;
        vec2 texMinMidCoord = texCoord - midCoord;
        signMidCoordPos = sign(texMinMidCoord);
        absMidCoordPos  = abs(texMinMidCoord);
    #endif

    #ifdef PERPENDICULAR_TWEAKS
        if (mat == 10003 || mat == 10005 || mat == 10015 || mat == 10017 || mat == 10019 || mat == 10029 || mat == 10039) { // Foliage
            #ifndef CONNECTED_GLASS_EFFECT
                vec2 midCoord = (gl_TextureMatrix[0] * mc_midTexCoord).st;
                vec2 texMinMidCoord = texCoord - midCoord;
            #endif
            vec3 normal = gl_NormalMatrix * gl_Normal;
            position.xyz += normal * sign(texMinMidCoord.y) * 0.2 * noonFactor * (1.0 + 0.01 * length(position.xyz));
        }
    #endif

    if (mat == 32000) { // Water
        position.y += 0.015 * max0(length(position.xyz) - 50.0); // WS752GH42G
    }

    vec3 normal = mat3(shadowModelViewInverse) * gl_NormalMatrix * gl_Normal;

    #if COLORED_LIGHTING_INTERNAL > 0
        if (gl_VertexID % 4 == 0) {
            UpdateVoxelMap(mat);
            #ifdef PUDDLE_VOXELIZATION
                UpdatePuddleVoxelMap(mat);
            #endif
            #if WORLD_SPACE_REFLECTIONS_INTERNAL > 0
                UpdateSceneVoxelMap(mat, normal, position.xyz);
            #endif
        }

        #if WORLD_SPACE_REFLECTIONS_INTERNAL > 0 && WORLD_SPACE_PLAYER_REF == 1
            UpdatePlayerVertexList(position.xyz);
        #endif

        #ifdef ACT_GROUND_LEAVES_FIX
            UpdateLeavesVoxelMap(mat);
        #endif
    #endif

    #ifdef END_PORTAL_BEAM_INTERNAL
        if (mat == 10556 && normal.y > 0.99 && length(position.xyz) < 32) SetEndPortalLoc(position.xyz);
    #endif

    #if END_CRYSTAL_VORTEX_INTERNAL > 0 || DRAGON_DEATH_EFFECT_INTERNAL > 0
        #if END_CRYSTAL_VORTEX_INTERNAL % 2 == 1
            if (entityId == 50000 && abs(normal.y) > 0.5 && abs(normal.y) < 0.8) { // End Crystal
                UpdateEndCrystalMap(position.xyz);
            }
        #endif
        #if END_CRYSTAL_VORTEX_INTERNAL / 2 == 1
            if (entityId == 50200) { // end crystal beam
                UpdateBeamMap(position.xyz);
            }
        #endif
    #endif
    #if END_CRYSTAL_VORTEX_INTERNAL / 2 == 1 || DRAGON_DEATH_EFFECT_INTERNAL > 0
        if (entityId == 50204) { // ender dragon
            UpdateDragonPos(position.xyz);
        }
    #endif

    gl_Position = shadowProjection * shadowModelView * position;

    #if DRAGON_DEATH_EFFECT_INTERNAL > 0
        #if EUPHORIA_PATCHES_VERSION >= 10903 || ANGELICA_VERSION >= 20134000
            #define FUCK entityId == 50208
            #define THE || false
            #define DRAGON || false
            #define DEATH || false
            #define BEAMS || false
        #else
            #if MC_VERSION >= 12100
                #define FUCK gl_Color.a == 1.0
                #define THE && (entityId == 0 || entityId == 50204)
            #else
                #define FUCK gl_Color.a < 0.5
                #define THE && entityId == 0
            #endif

            #define DRAGON && renderStage == MC_RENDER_STAGE_ENTITIES

            #ifndef IRIS_TAG_SUPPORT
                #define DEATH && abs(normal.y) > 0.8 && abs(normal.y) < 1.0
                #define BEAMS || false
            #else
                float dragonDeathFactor = 0.0001 * texelFetch(endcrystal_sampler, ivec2(35, 0), 0).r;
                float deathFadeFactor = exp(-3.0 * (1.0 - dragonDeathFactor)) * dragonDeathFactor;
                #define DEATH && deathFadeFactor > 1.0
                #if MC_VERSION >= 12100
                    #define BEAMS || renderStage == MC_RENDER_STAGE_NONE && gl_Color.a == 1.0
                #else
                    #define BEAMS || renderStage == MC_RENDER_STAGE_NONE && gl_Color.a < 0.5
                #endif
            #endif
        #endif

        // AAAAAAAAAHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH!!!!!!

        if (FUCK THE DRAGON DEATH BEAMS) {
            #ifndef IRIS_TAG_SUPPORT
                SetEndDragonDeath();
            #endif
            gl_Position = vec4(0.0);
        }
    #endif

    float lVertexPos = sqrt(gl_Position.x * gl_Position.x + gl_Position.y * gl_Position.y);
    float distortFactor = lVertexPos * shadowMapBias + (1.0 - shadowMapBias);
    gl_Position.xy *= 1.0 / distortFactor;
    gl_Position.z = gl_Position.z * 0.2;
}

#endif
