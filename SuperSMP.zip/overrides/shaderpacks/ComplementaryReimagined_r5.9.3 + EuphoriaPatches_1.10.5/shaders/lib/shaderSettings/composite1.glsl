#ifndef COMPOSITE_SETTINGS_FILE
#define COMPOSITE_SETTINGS_FILE

#include "/lib/shaderSettings/worldMotionBlur.glsl"

#define RAINBOWS 1 //[0 1 3]


// Euphoria Patches Settings


#define DARKER_DEPTH_OCEANS 0 //[1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 0]

#define EP_END_FLASH 0 //[0 1 2]
#ifdef EP_END_FLASH
#endif

#define NIGHT_DESATURATION_REMOVE_NEAR_LIGHTS

#define BLURRED_REFLECTIONS_I 10 //[0 1 2 3 4 5 6 7 8 9 10]

#endif
